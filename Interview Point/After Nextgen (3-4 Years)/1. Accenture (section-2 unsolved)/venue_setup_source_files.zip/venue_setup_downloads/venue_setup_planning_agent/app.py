import json
from pathlib import Path
from src.config import AgentConfig
from src.llm import OpenAIConstraintExtractor
from src.scheduler import Scheduler
from src.toolset import Toolset
from src.venue_agent import VenueAgent

def main():
    tasks = json.loads(Path("examples/tasks.json").read_text(encoding="utf-8"))
    brief = Path("examples/event_brief.txt").read_text(encoding="utf-8")
    agent = VenueAgent(OpenAIConstraintExtractor(), Scheduler(), Toolset(), AgentConfig())
    report = agent.run("FAIRGROUND-LIVE-001", tasks, brief)
    print(json.dumps(report.to_dict(), indent=2))

if __name__ == "__main__":
    main()
