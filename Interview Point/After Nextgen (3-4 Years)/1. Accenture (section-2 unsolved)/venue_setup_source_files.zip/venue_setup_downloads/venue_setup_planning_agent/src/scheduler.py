from collections import defaultdict
from .models import ScheduleEntry

class Scheduler:
    """Backtracking scheduler for integer slots, crew capacity, deadlines and task dependencies."""
    def valid_orderings(self, tasks, config, constraints):
        ordered = self._topological_order(list(tasks))
        if ordered is None:
            return
        entries, crew = {}, defaultdict(int)
        forbidden = {frozenset(pair) for pair in constraints.not_during}
        yielded = 0

        def overlap(a, b):
            return not (a.finish_slot < b.start_slot or b.finish_slot < a.start_slot)

        def search(i):
            nonlocal yielded
            if yielded >= config.max_schedules_to_consider:
                return
            if i == len(ordered):
                yielded += 1
                yield [entries[t.id] for t in ordered]
                return
            task = ordered[i]
            earliest = max((entries[d].finish_slot + 1 for d in task.depends_on), default=1)
            latest_finish = constraints.ready_by.get(task.id, config.total_slots)
            latest_start = min(config.total_slots - task.duration_slots + 1,
                               latest_finish - task.duration_slots + 1)
            for start in range(earliest, latest_start + 1):
                finish = start + task.duration_slots - 1
                candidate = ScheduleEntry(task.id, start, finish)
                if any(crew[s] + task.crew_required > config.crew_capacity
                       for s in range(start, finish + 1)):
                    continue
                if any(frozenset((task.id, other_id)) in forbidden and overlap(candidate, e)
                       for other_id, e in entries.items()):
                    continue
                for s in range(start, finish + 1):
                    crew[s] += task.crew_required
                entries[task.id] = candidate
                yield from search(i + 1)
                del entries[task.id]
                for s in range(start, finish + 1):
                    crew[s] -= task.crew_required
        yield from search(0)

    @staticmethod
    def _topological_order(tasks):
        by_id = {t.id: t for t in tasks}
        indegree = {t.id: 0 for t in tasks}
        children = {t.id: [] for t in tasks}
        for task in tasks:
            for dep in task.depends_on:
                if dep not in by_id:
                    return None
                indegree[task.id] += 1
                children[dep].append(task.id)
        ready = sorted(k for k, v in indegree.items() if v == 0)
        result = []
        while ready:
            current = ready.pop(0)
            result.append(by_id[current])
            for child in sorted(children[current]):
                indegree[child] -= 1
                if indegree[child] == 0:
                    ready.append(child)
                    ready.sort()
        return result if len(result) == len(tasks) else None
