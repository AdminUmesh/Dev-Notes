from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

class StepOutcome(str, Enum):
    SUCCESS = "SUCCESS"
    TRANSIENT_FAILURE = "TRANSIENT_FAILURE"
    PERMANENT_FAILURE = "PERMANENT_FAILURE"
    BLOCKED = "BLOCKED"

@dataclass
class SetupTask:
    id: str
    name: str
    duration_slots: int
    crew_required: int
    depends_on: list[str] = field(default_factory=list)
    mandatory: bool = False
    backup_of: Optional[str] = None

@dataclass
class EventConstraints:
    ready_by: dict[str, int] = field(default_factory=dict)
    not_during: list[list[str]] = field(default_factory=list)
    elevated_mandatory: list[str] = field(default_factory=list)
    drop_priority: list[str] = field(default_factory=list)
    confidence: float = 1.0

@dataclass(frozen=True)
class ScheduleEntry:
    task_id: str
    start_slot: int
    finish_slot: int

@dataclass
class ExecutionReport:
    event_id: str
    status: str
    schedule: list[dict] = field(default_factory=list)
    completed_task_ids: list[str] = field(default_factory=list)
    failed_task_ids: list[str] = field(default_factory=list)
    dropped_task_ids: list[dict] = field(default_factory=list)
    rejected_constraints: list[dict] = field(default_factory=list)
    trace: list[dict] = field(default_factory=list)
    error: Optional[str] = None

    def to_dict(self):
        return {
            "event_id": self.event_id, "status": self.status,
            "schedule": self.schedule, "completed_task_ids": self.completed_task_ids,
            "failed_task_ids": self.failed_task_ids, "dropped_task_ids": self.dropped_task_ids,
            "rejected_constraints": self.rejected_constraints, "trace": self.trace,
            "error": self.error,
        }
