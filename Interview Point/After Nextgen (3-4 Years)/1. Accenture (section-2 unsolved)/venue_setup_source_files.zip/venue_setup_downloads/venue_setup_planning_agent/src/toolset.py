from collections import deque
from .models import StepOutcome

class Toolset:
    """Deterministic simulator. Example: outcomes={'T2': ['TRANSIENT_FAILURE', 'SUCCESS']}."""
    def __init__(self, outcomes=None, call_ceiling=200):
        self._outcomes = {k: deque(v if isinstance(v, list) else [v])
                          for k, v in (outcomes or {}).items()}
        self._call_ceiling = call_ceiling
        self.calls = []

    def execute_task(self, task_id):
        if len(self.calls) >= self._call_ceiling:
            raise RuntimeError("Toolset call ceiling exceeded - runaway execution loop suspected")
        self.calls.append(task_id)
        queue = self._outcomes.get(task_id)
        if not queue:
            return StepOutcome.SUCCESS
        outcome = queue.popleft()
        return outcome if isinstance(outcome, StepOutcome) else StepOutcome(outcome)
