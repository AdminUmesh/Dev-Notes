import json
import os
from pathlib import Path

class OpenAIConstraintExtractor:
    """Uses OpenAI when configured; otherwise returns safe empty constraints for offline demos."""
    def __init__(self, extract_prompt_path="prompts/extract.txt",
                 repair_prompt_path="prompts/repair.txt", model=None, client=None):
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self._client = client
        self._last_raw_response = None
        self._extract_template = Path(extract_prompt_path).read_text(encoding="utf-8")
        self._repair_template = Path(repair_prompt_path).read_text(encoding="utf-8")
        if self._client is None and os.getenv("OPENAI_API_KEY"):
            from openai import OpenAI
            self._client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"),
                                  base_url=os.getenv("OPENAI_BASE_URL") or None)

    def extract(self, brief, tasks=None):
        task_list = "\n".join(f"{t.id}: {t.name}" for t in (tasks or []))
        if self._client is None:
            self._last_raw_response = json.dumps({
                "ready_by": {}, "not_during": [], "elevated_mandatory": [],
                "drop_priority": [], "confidence": 0.50
            })
            return self._last_raw_response
        prompt = self._extract_template.format(brief=brief, task_list=task_list)
        response = self._client.chat.completions.create(
            model=self.model, messages=[{"role": "user", "content": prompt}],
            temperature=0, response_format={"type": "json_object"})
        self._last_raw_response = response.choices[0].message.content
        return self._last_raw_response

    def repair(self, brief, tasks=None):
        if self._client is None or self._last_raw_response is None:
            raise RuntimeError("No malformed response available to repair.")
        task_list = "\n".join(f"{t.id}: {t.name}" for t in (tasks or []))
        prompt = self._repair_template.format(
            brief=brief, task_list=task_list, malformed_response=self._last_raw_response)
        response = self._client.chat.completions.create(
            model=self.model, messages=[{"role": "user", "content": prompt}],
            temperature=0, response_format={"type": "json_object"})
        self._last_raw_response = response.choices[0].message.content
        return self._last_raw_response

    def reset(self):
        self._last_raw_response = None
