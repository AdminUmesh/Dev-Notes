from dataclasses import dataclass

@dataclass
class AgentConfig:
    total_slots: int = 8
    crew_capacity: int = 6
    max_tool_calls: int = 30
    constraint_confidence_threshold: float = 0.70
    max_schedules_to_consider: int = 100
