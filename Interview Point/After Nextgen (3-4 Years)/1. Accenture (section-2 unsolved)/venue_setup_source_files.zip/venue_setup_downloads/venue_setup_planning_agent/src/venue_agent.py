import json
from .models import EventConstraints, ExecutionReport, SetupTask, StepOutcome
from .scheduler import Scheduler

class InvalidTaskError(Exception): pass
class CyclicDependencyError(Exception): pass

class VenueAgent:
    def __init__(self, llm_client, scheduler, toolset, config):
        self._llm_client, self._scheduler = llm_client, scheduler
        self._toolset, self._config = toolset, config

    def run(self, event_id, tasks, brief):
        completed, failed, dropped, rejected, trace = [], [], [], [], []
        self._llm_client.reset()
        try:
            parsed = self._parse_tasks(tasks)
        except CyclicDependencyError:
            return ExecutionReport(event_id, "failed", error="CYCLIC_DEPENDENCY")
        except InvalidTaskError:
            return ExecutionReport(event_id, "failed", error="INVALID_TASK")

        task_map = {t.id: t for t in parsed}
        backups = {t.backup_of: t for t in parsed if t.backup_of}
        primary = [t for t in parsed if t.backup_of is None]

        try:
            raw = self._llm_client.extract(brief, parsed)
            try:
                payload = json.loads(raw)
            except (TypeError, json.JSONDecodeError):
                payload = json.loads(self._llm_client.repair(brief, parsed))
            constraints, rejected = self._validate_constraints(payload, task_map)
        except Exception:
            return ExecutionReport(event_id, "failed", rejected_constraints=rejected,
                                   error="LLM_RESPONSE_INVALID")

        if constraints.confidence < self._config.constraint_confidence_threshold:
            rejected.append({"constraint": "all", "reason": "low_confidence"})
            constraints = EventConstraints(confidence=constraints.confidence)

        mandatory = {t.id for t in primary if t.mandatory}
        mandatory.update(constraints.elevated_mandatory)
        active = list(primary)
        schedules = list(self._scheduler.valid_orderings(active, self._config, constraints))

        for task_id in constraints.drop_priority:
            if schedules:
                break
            if task_id in mandatory:
                rejected.append({"constraint": "drop_priority", "task_id": task_id,
                                 "reason": "mandatory_task_cannot_be_dropped"})
                continue
            target = next((t for t in active if t.id == task_id), None)
            if target is None:
                continue
            active = [t for t in active if t.id != task_id]
            dropped.append({"task_id": task_id, "reason": "NO_FEASIBLE_SCHEDULE"})
            schedules = list(self._scheduler.valid_orderings(active, self._config, constraints))

        if not schedules:
            return ExecutionReport(event_id, "failed", dropped_task_ids=dropped,
                                   rejected_constraints=rejected, error="NO_VALID_SCHEDULE")

        chosen = schedules[0]
        schedule = [{"task_id": e.task_id, "start_slot": e.start_slot,
                     "finish_slot": e.finish_slot} for e in chosen]
        completed_set, tool_calls = set(), 0

        for entry in sorted(chosen, key=lambda e: (e.start_slot, e.task_id)):
            task = task_map[entry.task_id]
            if not all(dep in completed_set for dep in task.depends_on):
                failed.append(task.id)
                trace.append({"step": task.id, "kind": "execution", "attempt": 0,
                              "status": StepOutcome.BLOCKED.value})
                continue

            outcome, attempts, tool_calls = self._execute_with_retry(task.id, tool_calls)
            trace.extend({"step": task.id, "kind": "execution", "attempt": n,
                          "status": result.value} for n, result in attempts)

            if outcome == StepOutcome.SUCCESS:
                completed_set.add(task.id)
                completed.append(task.id)
                continue

            backup = backups.get(task.id)
            if backup and all(dep in completed_set for dep in backup.depends_on):
                backup_result, backup_attempts, tool_calls = self._execute_with_retry(
                    backup.id, tool_calls)
                trace.extend({"step": backup.id, "kind": "backup_execution", "attempt": n,
                              "status": result.value} for n, result in backup_attempts)
                if backup_result == StepOutcome.SUCCESS:
                    completed_set.add(task.id)
                    completed.append(task.id)
                    continue
            failed.append(task.id)

        status = "completed" if mandatory.issubset(completed_set) and not failed else "partial"
        return ExecutionReport(event_id, status, schedule, completed, failed, dropped,
                               rejected, trace,
                               None if status == "completed" else "ONE_OR_MORE_TASKS_NOT_COMPLETED")

    def _execute_with_retry(self, task_id, calls):
        attempts = []
        if calls >= self._config.max_tool_calls:
            return StepOutcome.BLOCKED, attempts, calls
        result = self._toolset.execute_task(task_id)
        calls += 1
        attempts.append((1, result))
        if result == StepOutcome.TRANSIENT_FAILURE and calls < self._config.max_tool_calls:
            result = self._toolset.execute_task(task_id)
            calls += 1
            attempts.append((2, result))
        return result, attempts, calls

    def _parse_tasks(self, tasks):
        if not isinstance(tasks, list):
            raise InvalidTaskError()
        parsed, seen = [], set()
        for raw in tasks:
            if isinstance(raw, SetupTask):
                data = vars(raw)
            elif isinstance(raw, dict):
                data = raw
            else:
                raise InvalidTaskError()
            if not {"id", "duration_slots", "crew_required"}.issubset(data):
                raise InvalidTaskError()
            task_id, duration, crew = data["id"], data["duration_slots"], data["crew_required"]
            deps, backup = data.get("depends_on", []), data.get("backup_of")
            if not isinstance(task_id, str) or not task_id or task_id in seen:
                raise InvalidTaskError()
            if not isinstance(duration, int) or isinstance(duration, bool) or duration <= 0:
                raise InvalidTaskError()
            if not isinstance(crew, int) or isinstance(crew, bool) or crew <= 0:
                raise InvalidTaskError()
            if not isinstance(deps, list) or not all(isinstance(x, str) for x in deps):
                raise InvalidTaskError()
            if backup is not None and not isinstance(backup, str):
                raise InvalidTaskError()
            seen.add(task_id)
            parsed.append(SetupTask(task_id, str(data.get("name", task_id)), duration,
                                    crew, list(deps), bool(data.get("mandatory", False)), backup))
        ids = {t.id for t in parsed}
        for t in parsed:
            if t.id in t.depends_on or any(d not in ids for d in t.depends_on):
                raise InvalidTaskError()
            if t.backup_of is not None and (t.backup_of not in ids or t.backup_of == t.id):
                raise InvalidTaskError()
        primary = [t for t in parsed if t.backup_of is None]
        if Scheduler._topological_order(primary) is None:
            raise CyclicDependencyError()
        return parsed

    def _validate_constraints(self, data, task_map):
        if not isinstance(data, dict):
            raise ValueError("Expected JSON object")
        keys = {"ready_by", "not_during", "elevated_mandatory", "drop_priority", "confidence"}
        if not keys.issubset(data):
            raise ValueError("Missing JSON fields")
        ready, pairs, elevated, drop, confidence = (
            data["ready_by"], data["not_during"], data["elevated_mandatory"],
            data["drop_priority"], data["confidence"])
        if not isinstance(ready, dict) or not all(isinstance(x, list) for x in [pairs, elevated, drop]):
            raise ValueError("Invalid field types")
        if not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or not 0 <= confidence <= 1:
            raise ValueError("Invalid confidence")
        ids, rejected = set(task_map), []
        valid_ready = {}
        for task_id, deadline in ready.items():
            if task_id not in ids:
                rejected.append({"constraint": "ready_by", "task_id": task_id, "reason": "unknown_task"})
            elif not isinstance(deadline, int) or isinstance(deadline, bool) or deadline < 1:
                rejected.append({"constraint": "ready_by", "task_id": task_id, "reason": "invalid_deadline"})
            else:
                valid_ready[task_id] = deadline
        valid_pairs = []
        for pair in pairs:
            if isinstance(pair, list) and len(pair) == 2 and all(isinstance(x, str) and x in ids for x in pair) and pair[0] != pair[1]:
                valid_pairs.append(pair)
            else:
                rejected.append({"constraint": "not_during", "value": pair, "reason": "invalid_pair"})
        valid_elevated, valid_drop = [], []
        for source, target, label in [(elevated, valid_elevated, "elevated_mandatory"),
                                      (drop, valid_drop, "drop_priority")]:
            for task_id in source:
                if isinstance(task_id, str) and task_id in ids and task_id not in target:
                    target.append(task_id)
                else:
                    rejected.append({"constraint": label, "task_id": task_id, "reason": "unknown_or_duplicate_task"})
        return EventConstraints(valid_ready, valid_pairs, valid_elevated, valid_drop,
                                float(confidence)), rejected
