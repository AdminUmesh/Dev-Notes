import json
import unittest
from src.config import AgentConfig
from src.models import StepOutcome
from src.scheduler import Scheduler
from src.toolset import Toolset
from src.venue_agent import VenueAgent

class FakeLLM:
    def __init__(self, payload): self.payload = payload
    def reset(self): pass
    def extract(self, brief, tasks): return json.dumps(self.payload)
    def repair(self, brief, tasks): return json.dumps(self.payload)

class AgentTests(unittest.TestCase):
    def agent(self, payload, outcomes=None):
        return VenueAgent(FakeLLM(payload), Scheduler(), Toolset(outcomes),
                          AgentConfig(total_slots=8, crew_capacity=6, max_tool_calls=20))
    def payload(self):
        return {"ready_by": {}, "not_during": [], "elevated_mandatory": [],
                "drop_priority": [], "confidence": 0.95}
    def test_dependencies_and_success(self):
        tasks = [{"id":"A","duration_slots":1,"crew_required":1,"mandatory":True},
                 {"id":"B","duration_slots":1,"crew_required":1,"depends_on":["A"]}]
        report = self.agent(self.payload()).run("E1", tasks, "A before B")
        self.assertEqual(report.status, "completed")
        self.assertEqual(report.completed_task_ids, ["A", "B"])
    def test_transient_retry(self):
        tasks = [{"id":"A","duration_slots":1,"crew_required":1,"mandatory":True}]
        agent = self.agent(self.payload(), {"A":[StepOutcome.TRANSIENT_FAILURE, StepOutcome.SUCCESS]})
        report = agent.run("E2", tasks, "Do A")
        self.assertEqual(report.status, "completed")
        self.assertEqual(len(report.trace), 2)
    def test_cycle(self):
        tasks = [{"id":"A","duration_slots":1,"crew_required":1,"depends_on":["B"]},
                 {"id":"B","duration_slots":1,"crew_required":1,"depends_on":["A"]}]
        report = self.agent(self.payload()).run("E3", tasks, "cycle")
        self.assertEqual(report.error, "CYCLIC_DEPENDENCY")

if __name__ == "__main__": unittest.main()
